
//*****************************************************************************
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
//#include "drivers/buttons.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/pwm.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "drivers/pinout.h"
#include "utils/uartstdio.h"
#include "tm4c129encpdt.h"
#include "FreeRTOSConfig.h"
#include "FreeRTOS/include/FreeRTOS.h"
#include "FreeRTOS/include/task.h"
#include "semphr.h"



//TickType_t now, then;

int a=0,b=0,c=1,d=0, ticks;

SemaphoreHandle_t xSemaphoreButton1;
SemaphoreHandle_t xSemaphoreButton2;


volatile bool button1Pressed = false;
volatile bool button2Pressed = false;

#define BUTTON1 (1 << 0) // PJ0
#define BUTTON2 (1 << 1) // PJ1

//LED blinking task
void LED1(void *pvParameters) {
    (void) pvParameters; //Avoid compiler warning

 //   TickType_t now1, then1;
    while(1)
        {

           if (xSemaphoreTake(xSemaphoreButton1, 0) == pdTRUE) { //Is active when 0
                    GPIO_PORTN_DATA_R |= (1 << 1); //Turn on LED 1 (PN1)
                    vTaskDelay(10000); //Wait for 10 seconds
                    //GPIO_PORTN_DATA_R &= ~(1 << 1); //Turn off LED 1
                }

               if(c==1)
                  {
                      c=0;

                      GPIO_PORTN_DATA_R |= (1 << 1);
                      vTaskDelay(1000);
                  }

                  else
                  {


                      GPIO_PORTN_DATA_R &= ~(1 << 1);
                      c=1;
                      vTaskDelay(1000);
                  }
                   //now1=xTaskGetTickCount();
                  // now1=now1-then1;

                   //vTaskDelay(133);

       }

}

void LED2(void *n)
{(void) n;

//TickType_t now2, then2;
while(1)
    {

    if (xSemaphoreTake(xSemaphoreButton2, 0) == pdTRUE) { // Active low
                GPIO_PORTN_DATA_R |= (1 << 0); // Turn on LED 2 (PN0)
                vTaskDelay(10000); // Wait for 10 seconds

            }

    //then2=xTaskGetTickCount();

        if(d==1)
           {
               d=0;

               GPIO_PORTN_DATA_R |= (1 << 0);
               vTaskDelay(2000);
           }
           else
           {


               GPIO_PORTN_DATA_R &= ~(1 << 0);
               d=1;
               vTaskDelay(2000);
           }
          // now2=xTaskGetTickCount();
          // now2=now2-then2;


}


}

void LED3(void *n)
{(void) n;
//TickType_t now3, then3;
while(1)
    {
    //then3=xTaskGetTickCount();
        if(a==1)
        {
            a=0;
            GPIO_PORTF_AHB_DATA_R |= (1 << 4);
           // GPIO_PORTF_AHB_DATA_R |= (1 << 0);
            vTaskDelay(4000);

        }
        else
        {

            GPIO_PORTF_AHB_DATA_R &= ~(1 << 4);
           // GPIO_PORTF_AHB_DATA_R &= ~(1 << 0);
            a=1;
            vTaskDelay(4000);

        }

    }
}

void LED4(void *n)
{(void) n;
//TickType_t now4, then4;
while(1)
    {
   // then4=xTaskGetTickCount();


        if(b==1)
               {
                   b=0;

                   GPIO_PORTF_AHB_DATA_R |= (1 << 0);
                   vTaskDelay(6000);

               }
               else
               {


                   GPIO_PORTF_AHB_DATA_R &= ~(1 << 0);
                   b=1;
                   vTaskDelay(6000);

               }

    }

}

void PortJIntHandler(void) {
    uint32_t status = GPIOIntStatus(GPIO_PORTJ_AHB_BASE, true); //Get interrupt status
    GPIOIntClear(GPIO_PORTJ_AHB_BASE, status); //Clear the interrupt

    if (status & BUTTON1) {
        xSemaphoreGiveFromISR(xSemaphoreButton1, NULL); //Button 1 pressed
    }
    if (status & BUTTON2) {
        xSemaphoreGiveFromISR(xSemaphoreButton2, NULL); //Button 2 pressed
    }
}


//Main function
int main(void) {

    //Set the system clock to use the PLL to get 120 MHz
    SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ|SYSCTL_OSC_MAIN|SYSCTL_USE_PLL|SYSCTL_CFG_VCO_480), 120000000);
    //Enable the GPIO port for the LED (D3 is PF4)
    SYSCTL_RCGCGPIO_R |= (1 << 5);   //Enable clock for Port F
    SysCtlDelay(1600 / 3);
    SYSCTL_RCGCGPIO_R |= (1 << 12);  //Enable clock for Port N
    SysCtlDelay(1600 / 3);
    SYSCTL_RCGCGPIO_R |= (1 << 8);   //Enable clock for Port J
    SysCtlDelay(1600 / 3);

    GPIO_PORTF_AHB_DIR_R |= (1 << 4);
    GPIO_PORTF_AHB_DIR_R |= (1 << 0);//Set PF4 as output (D3 LED)
    GPIO_PORTN_DIR_R |= (1 << 0);
    GPIO_PORTN_DIR_R |= (1 << 1);

    GPIO_PORTF_AHB_DEN_R |= (1 << 4);//Enable digital function for PF4
    GPIO_PORTF_AHB_DEN_R |= (1 << 0);
    GPIO_PORTN_DEN_R |= (1 << 0);//Enable digital function for PF4
    GPIO_PORTN_DEN_R |= (1 << 1);

    //Button/Switch 1 and 2.
    GPIO_PORTJ_AHB_DIR_R &= ~(BUTTON1 | BUTTON2); //Set PJ0 and PJ1 as input
    GPIO_PORTJ_AHB_DEN_R |= (BUTTON1 | BUTTON2); //Enable digital function for buttons
    GPIO_PORTJ_AHB_PUR_R |= (BUTTON1 | BUTTON2); //Enable pull-up resistors

    //Create semaphores
    xSemaphoreButton1 = xSemaphoreCreateBinary();
    xSemaphoreButton2 = xSemaphoreCreateBinary();

    //Set up interrupts for buttons
    GPIOIntRegister(GPIO_PORTJ_AHB_BASE, PortJIntHandler);
    GPIOIntTypeSet(GPIO_PORTJ_AHB_BASE, BUTTON1 | BUTTON2, GPIO_FALLING_EDGE);
    GPIOIntEnable(GPIO_PORTJ_AHB_BASE, BUTTON1 | BUTTON2);

    //Create the LED blinking task
    xTaskCreate(LED1, "LEDTask1", configMINIMAL_STACK_SIZE, NULL, 1, NULL);
    xTaskCreate(LED2, "LEDtask2", configMINIMAL_STACK_SIZE, NULL, 1, NULL);
    xTaskCreate(LED3, "LEDtask3", configMINIMAL_STACK_SIZE, NULL, 1, NULL);
    xTaskCreate(LED4, "LEDtask4", configMINIMAL_STACK_SIZE, NULL, 1, NULL);


    //Start the scheduler
    vTaskStartScheduler();

    //Should never reach here

    while (1)
    {



    }

}

