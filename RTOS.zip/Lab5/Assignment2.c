
//*****************************************************************************
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/pwm.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "drivers/pinout.h"
#include "uartstdio.h"
#include "tm4c129encpdt.h"
#include "FreeRTOSConfig.h"
#include "FreeRTOS/include/FreeRTOS.h"
#include "FreeRTOS/include/task.h"
#include "semphr.h"
#include "UART/configureUART.h"

//Semaphore for resource sharing between tasks
SemaphoreHandle_t xSemaphore; //730

void ConfigureUART(void){
    UART_reset(); //Call reset
    UART_init(); //Initialize UART
}

// Setup function to initialize the semaphore
void setup() {
    // Create a binary semaphore
    xSemaphore = xSemaphoreCreateBinary();
    // Start with the semaphore available (released)
    xSemaphoreGive(xSemaphore);
}

// Task function to simulate workload and semaphore usage
void vTaskFunction(void *pvParameters) {
    char buffer[100];


    while (1) {

        sprintf(buffer, "Task 1 started\n");
        UART_putString(buffer);

        // Take the semaphore (block until available)
        if (xSemaphoreTake(xSemaphore, portMAX_DELAY) == pdTRUE) {
            sprintf(buffer, "Task 1 sem take\n");
            UART_putString(buffer);

            sprintf(buffer, "Task 1 started its workload\n");
            UART_putString(buffer);
            SysCtlDelay(10000000);
            // Release the semaphore after work is done
            sprintf(buffer, "Task 1 sem give\n");
            sprintf(buffer, "Task 1 finished\n");
            UART_putString(buffer);
            UART_putString(buffer);
            xSemaphoreGive(xSemaphore);

        }





        //Wait for a period before starting again (simulate task periodicity)
        //Wait for the next period
        vTaskDelay(100);  // Delay for 200 ticks
    }
}

void vTaskFunction2(void *pvParameters) {
    char buffer[100];


    while (1) {

        sprintf(buffer, "Task 2 started\n");
        UART_putString(buffer);

        // Take the semaphore (block until available)


            sprintf(buffer, "Task 2 started its workload\n");
            UART_putString(buffer);
            SysCtlDelay(5000000);

        sprintf(buffer, "Task 2 finished\n");
        UART_putString(buffer);

        // Wait for a period before starting again (simulate task periodicity)
        vTaskDelay(100);  // Delay for 200 ticks
    }
}

void vTaskFunction3(void *pvParameters) {
    char buffer[100];

    while (1) {

        sprintf(buffer, "Task 3 started\n");
        UART_putString(buffer);

        // Take the semaphore (block until available)
        if (xSemaphoreTake(xSemaphore, portMAX_DELAY) == pdTRUE) {
            sprintf(buffer, "Task 3 sem take\n");
            UART_putString(buffer);

            sprintf(buffer, "Task 3 started its workload\n");
            UART_putString(buffer);

            SysCtlDelay(5000000);


            // Release the semaphore after work is done
            sprintf(buffer, "Task 3 sem give\n");
            xSemaphoreGive(xSemaphore);

            UART_putString(buffer);
        }

        sprintf(buffer, "Task 3 finished\n");
        UART_putString(buffer);

       vTaskDelay(100);  // Delay
    }
}


int main(void) {


    setup();  //Initialize the semaphore
    ConfigureUART(); //Configuring UART from lab 4

    //Create tasks with different priorities
    xTaskCreate(vTaskFunction, "Task 1", configMINIMAL_STACK_SIZE + 200, NULL, 1, NULL);  // Task 1: Low priority
    xTaskCreate(vTaskFunction2, "Task 2", configMINIMAL_STACK_SIZE + 200, NULL, 2, NULL);  // Task 2: Medium priority
    xTaskCreate(vTaskFunction3, "Task 3", configMINIMAL_STACK_SIZE + 200, NULL, 3, NULL);  // Task 3: High priority

    // Start the FreeRTOS scheduler
    vTaskStartScheduler();

    // The code below should never be reached because FreeRTOS takes control
    while (1);
}
