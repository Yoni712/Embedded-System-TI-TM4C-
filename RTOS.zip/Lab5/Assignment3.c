
//*****************************************************************************
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/pwm.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "drivers/pinout.h"
#include "uartstdio.h"
#include "tm4c129encpdt.h"
#include "FreeRTOSConfig.h"
#include "FreeRTOS/include/FreeRTOS.h"
#include "FreeRTOS/include/task.h"
#include "semphr.h"
#include "UART/configureUART.h"

//Semaphore for resource sharing between tasks
SemaphoreHandle_t xSemaphore; //730

void ConfigureUART(void){
    UART_reset(); //Call reset
    UART_init(); //Initialize UART
}

// Setup function to initialize the semaphore
void setup() {
    // Create a binary semaphore
    xSemaphore = xSemaphoreCreateBinary();
    // Start with the semaphore available (released)
    xSemaphoreGive(xSemaphore);
}

// Deadline miss detection function
void detectDeadlineMiss(char *taskName, TickType_t deadline, TickType_t currentTick) {
    if (currentTick > deadline) {
        char buffer[100];
        TickType_t delay = currentTick - deadline;
        sprintf(buffer, "%s missed its deadline by %d ticks\n", taskName, delay);
        UART_putString(buffer);
    }
}

// Task function to simulate workload and semaphore usage
void vTaskFunction(void *pvParameters) {
    char buffer[100];
    TickType_t time = 50; //Let's say that the deadline for this task is 50 ticks.

    while (1) {
        TickType_t startTime = xTaskGetTickCount();  //Get the start time
        TickType_t deadline = startTime + time;  //Define the deadline for this task
        sprintf(buffer, "Task 1 started\n");
        UART_putString(buffer);

        // Take the semaphore (block until available)
        if (xSemaphoreTake(xSemaphore, portMAX_DELAY) == pdTRUE) {
            sprintf(buffer, "Task 1 sem take\n");
            UART_putString(buffer);

            sprintf(buffer, "Task 1 started its workload\n");
            UART_putString(buffer);
            SysCtlDelay(5000000);
            // Release the semaphore after work is done
            sprintf(buffer, "Task 1 sem give\n");
            UART_putString(buffer);
            xSemaphoreGive(xSemaphore);

        }

        sprintf(buffer, "Task 1 finished\n");
        UART_putString(buffer);

        TickType_t currentTick = xTaskGetTickCount(); //Here we get the end time
        detectDeadlineMiss("Task 1", deadline, currentTick);

        //Wait for a period before starting again (simulate task periodicity)
        //Wait for the next period
        vTaskDelay(100);  // Delay for 200 ticks
    }
}

void vTaskFunction2(void *pvParameters) {
    char buffer[100];
    TickType_t time = 50; //Let's say that the deadline for this task is 50 ticks.

    while (1) {
        TickType_t startTime = xTaskGetTickCount();  // Get the start time
        TickType_t deadline = startTime + time;  // Define the deadline for this task
        sprintf(buffer, "Task 2 started\n");
        UART_putString(buffer);

        // Take the semaphore (block until available)


            sprintf(buffer, "Task 2 started its workload\n");
            UART_putString(buffer);
            SysCtlDelay(1000000);


            // Release the semaphore after work is done




        TickType_t currentTick = xTaskGetTickCount();
        detectDeadlineMiss("Task 2", deadline, currentTick);

        sprintf(buffer, "Task 2 finished\n");
        UART_putString(buffer);

        // Wait for a period before starting again (simulate task periodicity)
        vTaskDelay(100);  // Delay for 200 ticks
    }
}

void vTaskFunction3(void *pvParameters) {
    char buffer[100];
    TickType_t time = 50; //Let's say that the deadline for this task is 50 ticks.
    while (1) {
        TickType_t startTime = xTaskGetTickCount();  // Get the start time
        TickType_t deadline = startTime + time;  // Define the deadline for this task
        sprintf(buffer, "Task 3 started\n");
        UART_putString(buffer);

        // Take the semaphore (block until available)
        if (xSemaphoreTake(xSemaphore, portMAX_DELAY) == pdTRUE) {
            sprintf(buffer, "Task 3 sem take\n");
            UART_putString(buffer);

            sprintf(buffer, "Task 3 started its workload\n");
            UART_putString(buffer);

            SysCtlDelay(1000000);


            // Release the semaphore after work is done
            sprintf(buffer, "Task 3 sem give\n");
            xSemaphoreGive(xSemaphore);

            UART_putString(buffer);
        }

        sprintf(buffer, "Task 3 finished\n");
        UART_putString(buffer);

        TickType_t currentTick = xTaskGetTickCount();
        detectDeadlineMiss("Task 3", deadline, currentTick);

       vTaskDelay(100);  // Delay
    }
}


int main(void) {


    setup();  //Initialize the semaphore
    ConfigureUART(); //Configuring UART from lab 4

    //Create tasks with different priorities
    xTaskCreate(vTaskFunction, "Task 1", configMINIMAL_STACK_SIZE + 200, NULL, 1, NULL);  // Task 1: Low priority
    xTaskCreate(vTaskFunction2, "Task 2", configMINIMAL_STACK_SIZE + 200, NULL, 2, NULL);  // Task 2: Medium priority
    xTaskCreate(vTaskFunction3, "Task 3", configMINIMAL_STACK_SIZE + 200, NULL, 3, NULL);  // Task 3: High priority

    // Start the FreeRTOS scheduler
    vTaskStartScheduler();

    // The code below should never be reached because FreeRTOS takes control
    while (1);
}
