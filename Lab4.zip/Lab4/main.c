#include <tm4c129encpdt.h>
#include <stdint.h>



//19.4 Initialization and Configuration from the datasheet.
void UART_init(){
    //1.Enable the UART module using the RCGCUART register (see page 395).
    SYSCTL_RCGCUART_R |= (1<<0);

    //2. Enable the clock to the appropriate GPIO module via the RCGCGPIO register (see page 389).
    //To find out which GPIO port to enable, refer to Table 29-5 on page 1932.
    SYSCTL_RCGCGPIO_R |= (1<<0);
    volatile int delay = SYSCTL_RCGCUART_R;

    //3. Set the GPIO AFSEL bits for the appropriate pins (see page 778). To determine which GPIOs to
    //configure, see Table 29-4 on page 1921.
    GPIO_PORTA_AHB_AFSEL_R |= (1<<0) | (1<<1); // PA0 (Rx) and PA1 (Tx)

    //4. Configure the GPIO current level and/or slew rate as specified for the mode selected (see
    //page 780 and page 788).

    //5. Configure the PMCn fields in the GPIOPCTL register to assign the UART signals to the appropriate
    //pins (see page 795 and Table 29-5 on page 1932).
    //GPIO_PORTA_AHB_PCTL_R &= ~((1 << 0) | (1 << 4)); // Clear PCTL for PA0, PA1
    GPIO_PORTA_AHB_PCTL_R |= (1 << 0) | (1 << 4); // Set PCTL for PA0, PA1 as UART
    GPIO_PORTA_AHB_DEN_R |= (1<<0) | (1<<1);

    //BRD = 16,000,000 / (16 * 9600) = 104.1666...
    //UARTFBRD[DIVFRAC] = integer(0.1666 * 64 + 0.5) = integer(11.16624) = 11

    //1. Disable the UART by clearing the UARTEN bit in the UARTCTL register.
    UART0_CTL_R &= ~(1 << 0); // why can't we just UART0->CTL = (0<<0); Try if it's the same

    //2. Write the integer portion of the BRD to the UARTIBRD register.
    UART0_IBRD_R = 104;

    //3. Write the fractional portion of the BRD to the UARTFBRD register.
    UART0_FBRD_R = 11;

    //4. Write the desired serial parameters to the UARTLCRH register (in this case, a value of
    //0x0000.0060).
    UART0_LCRH_R = (0x3<<5); // value 3 on bit 5 for 8-bit length.

    //5. Configure the UART clock source by writing to the UARTCC register.
    UART0_CC_R = 0;

    //6. Optionally, configure the �DMA channel (see �Micro Direct Memory Access (DMA)� on page 686)
    //and enable the DMA option(s) in the UARTDMACTL register.
    //UART0->DMACTL = ()

    //7. Enable the UART by setting the UARTEN bit in the UARTCTL register.
    UART0_CTL_R = (1<<0) | (1<<8) | (1<<9);
}





char UART_getChar(void){
    char c;//char is 8-bit of data.
    while((UART0_FR_R & (1<<4)) != 0); //Checks until the receiver is not empty so that we can save what ever was sent.

    //Since we want to save data that comes in, so everytime the receiver has something stored then it gets saved on to the char c.
    c = UART0_DR_R;
    //We are calling on UART_putChar so that we can print out whatever was sent through the UART.
    UART_putChar(c);
    return c;
}




void UART_putChar(char c){
   while((UART0_FR_R & (1<<5)) != 0); //waits to check if the transmitter is empty so it can transmit c.
   UART0_DR_R = c;
}



//We are using Universal Asynchronous Receiver/Transmitter Software Reset (SRUART) to reset the UART.
void UART_reset() {

    SYSCTL_SRUART_R = (1<<0);

    SYSCTL_SRUART_R = (0<<0);


}


void UART_putString(char* string){

    while(*string !='\0')//Goes through the string until it's at the end.
    {
        //Using put char function to print out every character one at a time.
        UART_putChar(*(string++));

    }
    //new line
  UART_putChar('\n');
}




void UART_getString(char string[]){
    int r=0;
    char get = 's'; //Setting it equal to a random character in the beginning, since it will be used in the while loop below.
    while(get !='\r') //Continue reading characters until the carriage return '\r' is received
        {
        get=UART_getChar(); //Read a character from the UART with the help of UART_getChar function
          string[r]=get; //Storing the character in the string array

          r++; //Increment the index for the next character
        }
    string[r] = '\0'; //Here we are Null-terminating the string to mark the end
    UART_putChar('\n'); // And here we are sending a newline character to indicate end of input so that we can start of on a newline on the terminal.

}




int main(void) {
volatile int i;
UART_reset(); //Call reset
UART_init(); //Initialize UART

UART_putString("\033[2J\033[H");
char UART_text[100];
        while (1)
        {

            UART_getString(UART_text); //Getting a string of what was written on the terminal.
            UART_putString(&UART_text); //Printing on to the terminal of what was written on the terminal.

            if (UART_text[0]=='e'&&UART_text[1]=='n'&&UART_text[2]=='d')//Looking through the word "end" on the string that was written on the terminal.
                                                                        //It just need to start with "end" in order to end the program.
            {
                break; //Goes out of the loop if "end" was written on the terminal
            }

        }
        UART_putString("end of the project"); // printing this out in order for the user to know that the program has ended.
        UART_reset(); //reseting the UART for new application.


}
