//#include "low-level-codes/configureTimer.h"

/*
 * configureTimer.h
 *
 *  Created on: 27 sep. 2024
 *      Author: yme21001
 */

#ifndef LOW_LEVEL_CODES_CONFIGURETIMER_H_
#define LOW_LEVEL_CODES_CONFIGURETIMER_H_


extern void ConfigureTimer();
extern void Timer0IntHandler();

extern volatile uint32_t seconds;
extern volatile uint32_t minutes;
extern volatile uint32_t hours;
extern volatile uint32_t paus;

#endif /* LOW_LEVEL_CODES_CONFIGURETIMER_H_ */
