//#include "low-level-codes/varibels.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "drivers/buttons.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/pwm.h"
#include "driverlib/sysctl.h"

#ifndef LOW_LEVEL_CODES_VARIBELS_H_
#define LOW_LEVEL_CODES_VARIBELS_H_

/*
extern uint32_t seconds = 0;
extern uint32_t minutes = 0;
extern uint32_t hours = 0;
extern uint32_t paus = 1;

*/
#endif /* LOW_LEVEL_CODES_CONFIGURETIMER_H_ */


