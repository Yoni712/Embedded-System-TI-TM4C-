#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
//#include "drivers/buttons.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/pwm.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "drivers/pinout.h"
#include "utils/uartstdio.h"
#include "inc/tm4c129encpdt.h"
#include "driverlib/adc.h"
#include "driverlib/timer.h"
#include "low-level-codes/varibels.h"
#include "low-level-codes/configureTimer.h"
#include "low-level-codes/configureUART.h"
/*
 * varibels.c
 *
 *  Created on: 27 sep. 2024
 *      Author: yme21001
 */




