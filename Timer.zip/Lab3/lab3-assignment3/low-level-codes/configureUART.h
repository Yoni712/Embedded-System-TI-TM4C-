//#include "low-level-codes/configureUART.c"


/*
 * configureTimer.h
 *
 *  Created on: 27 sep. 2024
 *      Author: yme21001
 */

#ifndef LOW_LEVEL_CODES_CONFIGURETIMER_H_
#define LOW_LEVEL_CODES_CONFIGURETIMER_H_

extern void UARTIntHandler();
extern void ConfigureUART();


#endif /* LOW_LEVEL_CODES_CONFIGURETIMER_H_ */
