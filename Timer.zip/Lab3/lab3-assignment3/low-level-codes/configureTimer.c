#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
//#include "drivers/buttons.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/pwm.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "drivers/pinout.h"
#include "utils/uartstdio.h"
#include "inc/tm4c129encpdt.h"
#include "driverlib/adc.h"
#include "driverlib/timer.h"
#include "low-level-codes/configureTimer.h"
#include "low-level-codes/configureUART.h"


volatile uint32_t seconds = 0;
volatile uint32_t minutes = 0;
volatile uint32_t hours = 0;
volatile uint32_t paus = 1;

void Timer0IntHandler(void) {
    //Clear the timer interrupt
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    if(paus==1){

    //Increment the seconds
    seconds++;

    //Increment minute if second reach 60 and also increment hour if minute reaches 60.
    if (seconds >= 60) {
        seconds = 0; //Reset seconds
        minutes++;   //Increment minutes
    }
    if (minutes >= 60) {
        minutes = 0; //Reset minutes
        hours++;     //Increment hours
    }

    UARTprintf("\033[2J\033[H"); //clear the terminal
    UARTprintf("Time: %02d:%02d:%02d\n",hours ,minutes , seconds); //Print the timer

    //Reload the timer for the next second
    TimerLoadSet(TIMER0_BASE, TIMER_A, 16000000 * 1.5);

    }
}



void ConfigureTimer(void) {
    //Enable the Timer0 peripheral
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);

    //Wait for the Timer0 module to be ready
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER0)) {
    }

    //Configure TimerA as a periodic timer
    TimerConfigure(TIMER0_BASE, TIMER_CFG_A_PERIODIC);

    //Load the timer with the value for 1 second (16 MHz clock)
    TimerLoadSet(TIMER0_BASE, TIMER_A, 16000000 * 1.5); //Load for 1 second

    //Enable Timer0A interrupt
    TimerIntRegister(TIMER0_BASE, TIMER_A, Timer0IntHandler);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    //Enable the timer
    TimerEnable(TIMER0_BASE, TIMER_A);
    //UARTprintf("Timer Enabled\n");
}

