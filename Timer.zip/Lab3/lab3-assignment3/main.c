#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/pwm.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "drivers/pinout.h"
#include "utils/uartstdio.h"
#include "inc/tm4c129encpdt.h"
#include "driverlib/adc.h"
#include "driverlib/timer.h"
#include "low-level-codes/configureTimer.h"
#include "low-level-codes/configureUART.h"


int main(void) {
    //Set the system clock to 16 MHz
    SysCtlClockFreqSet((SYSCTL_XTAL_16MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480), 16000000);

    char a[3]="st";
    char second1[3];
    char minutes2[3];
    char hour9[3];


    //Configure UART for debugging
    ConfigureUART();

    //Configure the Timer
    ConfigureTimer();

    //Enable processor interrupts
    IntMasterEnable();

    //Main loop
    while (1) {

       UARTgets( a, sizeof(a));
       //"sp" is to stop the clock
       if(strcmp(a,"sp")==0)
       {
            paus=0;
       }
       //"st" is to start the clock
       if(strcmp(a,"st")==0)
       {
            paus=1;
       }
       //"re" is to reset the clock
       if(strcmp(a,"re")==0){
            hours=0;
            minutes=0;
            seconds=0;
       }

       if(paus==0)
       {
           //"in" is to initialise and be able to put in values for second, minute, and hour.
            if(strcmp(a,"in")==0)
            {
                UARTprintf("Seconds: ");
                UARTgets( second1, sizeof(second1));
                UARTprintf("Minutes: ");
                UARTgets( minutes2, sizeof(minutes2));
                UARTprintf("Hours: ");
                UARTgets( hour9,sizeof(hour9));
                hours=atoi(hour9);
                minutes=atoi(minutes2);
                seconds=atoi(second1);
                paus=1;
            }

       }

    }

}
