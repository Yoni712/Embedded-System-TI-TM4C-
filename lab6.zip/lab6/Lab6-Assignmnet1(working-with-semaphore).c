#include <stdbool.h>
#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "UART/configureUART.h"
#include "driverlib/sysctl.h"
#include <stdlib.h>


#define BUFFER_SIZE 15  // Define the size of the shared buffer

// Shared variables
uint8_t buffer[BUFFER_SIZE];  // Buffer for storing produced bytes
int Write = 0, Read=0;


// Semaphores
SemaphoreHandle_t Mute;          // Mutex to protect buffer access
SemaphoreHandle_t FullSemaphore;  // Counting semaphore for full buffer
SemaphoreHandle_t EmptySemaphore; // Counting semaphore for empty buffer

void ConfigureUART(void){
    UART_reset(); //Call reset
    UART_init(); //Initialize UART
}


//Producer task
void vProducerTask(void *pvParameters) {
char text[100];


while(1){

                if(xSemaphoreTake(EmptySemaphore, portMAX_DELAY) == pdTRUE)
                {
                    xSemaphoreTake(Mute, portMAX_DELAY);

                    buffer[Write]=5;
                    sprintf(text, "added in spot %d\n", Write);
                    UART_putString(text);
                    Write++;


                    xSemaphoreGive(Mute);
                    xSemaphoreGive(FullSemaphore);
               }
                if(Write == 15){
                    Write = 0;
                }
                vTaskDelay(pdMS_TO_TICKS(150));


        }
    }




// Consumer task
void vConsumerTask(void *pvParameters) {

    char text[100];

    while(1){




                    if(xSemaphoreTake(FullSemaphore, portMAX_DELAY) == pdTRUE)
                    {
                        xSemaphoreTake(Mute, portMAX_DELAY);

                        buffer[Read]=5;
                        sprintf(text, "removed in spot %d\n", Read);
                        UART_putString(text);
                        Read++;


                        xSemaphoreGive(Mute);
                        xSemaphoreGive(EmptySemaphore);
                   }
                    if(Read == 15){
                         Read = 0;
                    }
                    vTaskDelay(pdMS_TO_TICKS(150));

            }

   }



int main(void) {

    //SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ|SYSCTL_OSC_MAIN|SYSCTL_USE_PLL|SYSCTL_CFG_VCO_480), 120000000);

    ConfigureUART();
    //Both producer and consumer tasks might access the buffer without considering if it has room (in the case of the producer) or if it has items (in the case of the consumer).
    //This can lead to data corruption, buffer overflows, or reading invalid data from empty slots.
    FullSemaphore = xSemaphoreCreateCounting(BUFFER_SIZE, 0);
    EmptySemaphore = xSemaphoreCreateCounting(BUFFER_SIZE, BUFFER_SIZE);
    Mute = xSemaphoreCreateMutex();



    xTaskCreate(vProducerTask, "produce", configMINIMAL_STACK_SIZE + 200, NULL, 1, NULL);

    xTaskCreate(vConsumerTask, "consume", configMINIMAL_STACK_SIZE + 200, NULL, 1, NULL);

    vTaskStartScheduler();
}
