#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "inc/hw_memmap.h"
#include "driverlib/interrupt.h"
#include "UART/configureUART.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "tm4c129encpdt.h"
#include "driverlib/adc.h"
#include <math.h>
#include "FreeRTOSConfig.h"


//Queues for each sensor
xQueueHandle xQueueJoystick, xQueueAccelerometer, xQueueMic;

uint32_t Information[6], joystick[2], accele[3], mic;
//ADC channel definitions
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
while(1);
}
#endif

void ConfigureUART(void){
    //Enable GPIOA peripheral.
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    //Enable UART0 peripheral.
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    //Configure PA0 as UART0 RX.
    GPIOPinConfigure(GPIO_PA0_U0RX);
    //Configure PA1 as UART0 TX.
    GPIOPinConfigure(GPIO_PA1_U0TX);
    //Set PA0 and PA1 as UART pins.
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    //Set UART clock source.
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);
    //Configure UART for 115200 baud rate.
    UARTStdioConfig(0, 115200, 16000000);
}

//Task Priorities
#define TASK_PRIORITY      (tskIDLE_PRIORITY + 1)

//Collects the information
void informationHandler(){
    
    ADCProcessorTrigger(ADC0_BASE, 0);

            //Wait for ADC conversion to complete for X-axis
            while (!ADCIntStatus(ADC0_BASE, 0, false)) {}

            ADCSequenceDataGet(ADC0_BASE, 0, Information);  //Fetch X-axis value
            ADCIntClear(ADC0_BASE, 0);  //Clear interrupt flag for X-axis

            joystick[0] = Information[0];
            joystick[1] = Information[1];
            accele[0] = Information[2];
            accele[1] = Information[3];
            accele[2] = Information[4];
            mic = Information[5];
}

//Joystick Task
void vJoystickTask(void *pvParameters)
{
    char text[100];


    while (1)
    {
        informationHandler();
        //Send data to the queue

        xQueueSend(xQueueJoystick, &joystick, 100);

        //Delay for 5 for the hormonics
        vTaskDelay(5);
    }
}

//Accelerometer Task
void vAccelTask(void *pvParameters)
{
    char text[100];

    while (1)
    {

        informationHandler();
        //Send data to the queue
        xQueueSend(xQueueAccelerometer, &accele, 100);


        //Delay for 10
        vTaskDelay(10);
    }
}

//Microphone Task
void vMicTask(void *pvParameters)
{
    char text[100];

    while (1)
    {
      
        informationHandler();
        //Send data to the queue
        xQueueSend(xQueueMic, &mic, 100);
        //Delay for 20
        vTaskDelay(20);
        
    }
}

//Gatekeeper Task
void vGatekeeperTask(void *pvParameters)
{
    char text[50];
    uint32_t joystickData[2], arrValue[3], mic1;  // Use uint32_t for correct ADC value type
    uint32_t joystickAverage[2], accelerometerAverage[3], micAva;

    int i;

    while (1)
    {

        //Fetch joystick data from the queue and compute the average over 4 readings
        for (i = 0; i < 4; i++) {
            if (xQueueReceive(xQueueJoystick, &joystickData, 0) == pdPASS) {
                joystickAverage[0] += joystickData[0];  //X-axis
                joystickAverage[1] += joystickData[1];  //Y-axis
            }
        }

        //Compute the average values
        joystickAverage[0] /= 4;  //Average X-axis
        joystickAverage[1] /= 4;  //Average Y-axis


        //Fetch accelerometer data from the queue and compute the average over 2 readings
        for (i = 0; i < 2; i++) {
            if (xQueueReceive(xQueueAccelerometer, &arrValue, 0) == pdPASS) {
                accelerometerAverage[0] += arrValue[0];  //X-axis
                accelerometerAverage[1] += arrValue[1];  //Y-axis
                accelerometerAverage[2] += arrValue[2];  //Y-axis

            }
        }

        //Compute the average values
        accelerometerAverage[0] /= 2;  //Average X-axis
        accelerometerAverage[1] /= 2;  //Average Y-axis
        accelerometerAverage[2] /= 2;  //Average Y-axis


        //Fetch microphone data from the queue and compute the average over 2 readings
        for (i = 0; i < 8; i++) {
             if (xQueueReceive(xQueueMic, &mic1, 0) == pdPASS) {
                 micAva += mic1;

             }
        }

        //Compute the average values and converting into decible
        micAva /= 8;
        micAva = 20*log(mic1/200);


        //Print the averaged datas to UART
        UARTprintf("\033[2J\033[H");  //Clear screen
        sprintf(text, "Joystick: %u, %u\n\r", joystickAverage[0], joystickAverage[1]);  
        UARTprintf(text);
        sprintf(text, "Accelerometer: %u, %u, %u\n\r", accelerometerAverage[0], accelerometerAverage[1], accelerometerAverage[2]);  
        UARTprintf(text);
        sprintf(text, "Microphone: %u\n\r", micAva);  
        UARTprintf(text);
        //Delay to match sensor polling rates

        //Reset averages after each printout
        joystickAverage[0] = 0;
        joystickAverage[1] = 0;
        accelerometerAverage[0]= 0;
        accelerometerAverage[1]= 0;
        accelerometerAverage[1]= 0;
        micAva = 0;

        vTaskDelay(40);
    }

}


// UART initialization function

// ADC Initialization function
void InitADC(void)
{

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOE)) {}
    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_5);

    //Enable the ADC peripheral.
        SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
        //SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC1);
        ADCHardwareOversampleConfigure(ADC0_BASE, 64);

        //Wait for the ADC0 module to be ready.
        while (!SysCtlPeripheralReady(SYSCTL_PERIPH_ADC0)) {
        }
        
      //Seting the sequense 0
    ADCSequenceConfigure(ADC0_BASE, 0, ADC_TRIGGER_PROCESSOR, 0);
    ADCSequenceStepConfigure(ADC0_BASE, 0, 0, ADC_CTL_CH9 | ADC_CTL_IE);
    ADCSequenceStepConfigure(ADC0_BASE, 0, 1, ADC_CTL_CH0 | ADC_CTL_IE);
    ADCSequenceStepConfigure(ADC0_BASE, 0, 2, ADC_CTL_CH3 | ADC_CTL_IE);
    ADCSequenceStepConfigure(ADC0_BASE, 0, 3, ADC_CTL_CH2 | ADC_CTL_IE);
    ADCSequenceStepConfigure(ADC0_BASE, 0, 4, ADC_CTL_CH1 | ADC_CTL_IE);
    ADCSequenceStepConfigure(ADC0_BASE, 0, 5, ADC_CTL_CH8 | ADC_CTL_IE | ADC_CTL_END);
    ADCSequenceEnable(ADC0_BASE, 0);

}

// Main function
int main(void)
{
    //Set the clock
    SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ|SYSCTL_OSC_MAIN|SYSCTL_USE_PLL|SYSCTL_CFG_VCO_480), 16000000);
    ConfigureUART();
    //Initialize the UART for output

    IntMasterEnable();
    //Initialize ADC peripherals
    InitADC();
    
    //Create message queues for sensors
    xQueueJoystick = xQueueCreate(4, sizeof(uint32_t) * 2); // Joystick x, y
    xQueueAccelerometer = xQueueCreate(2, sizeof(uint32_t) * 3); // Accelerometer x, y, z
    xQueueMic = xQueueCreate(8, sizeof(uint32_t));

    //Create tasks for sensors and gatekeeper
    xTaskCreate(vJoystickTask, "JoystickTask", configMINIMAL_STACK_SIZE, NULL, TASK_PRIORITY, NULL);
    xTaskCreate(vAccelTask, "AccelerometerTask", configMINIMAL_STACK_SIZE, NULL, TASK_PRIORITY, NULL);
    xTaskCreate(vMicTask, "MicrophoneTask", configMINIMAL_STACK_SIZE, NULL, TASK_PRIORITY, NULL);
    xTaskCreate(vGatekeeperTask, "GatekeeperTask", configMINIMAL_STACK_SIZE, NULL, TASK_PRIORITY, NULL);

    //Start the scheduler
    vTaskStartScheduler();

    //Code should never reach here
    while (1) {}
}
