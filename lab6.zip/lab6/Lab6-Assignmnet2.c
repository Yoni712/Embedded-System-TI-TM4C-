#include <stdbool.h>
#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "inc/hw_memmap.h"
#include "driverlib/interrupt.h"
#include "UART/configureUART.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "tm4c129encpdt.h"
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE 15
#define BUTTON1 (1 << 0) // PJ0
SemaphoreHandle_t xSemaphoreButton1;

char buffer[BUFFER_SIZE];
int currentLength = 0, amountChar = 0;
int status_taskFlag = 0;

void ConfigureUART(void) {
    UART_reset();
    UART_init();
}

void vstatus_task(void* pvParameters) {

    while (1) {
        char text[50];
        //Wait for the semaphore to be given by the interrupt handler
        if (xSemaphoreTake(xSemaphoreButton1, portMAX_DELAY) == pdTRUE) {
            status_taskFlag = 1;
            UART_putString("\033[H\033[J");
            UART_putString(buffer);
                        sprintf(text, "\n\rCharacters: %d", amountChar); //Add spaces for cleanup
                        UART_putString(text); //Display the new text

            vTaskDelay(1000);
            status_taskFlag = 0;
            UART_putString("\033[H\033[J");
            UART_putString(buffer);

        }
        vTaskDelay(10);
    }
}

//Task to handle UART communication
void vuartTask(void* pvParameters) {
    while (1) {


        char receivedChar = UART_getChar(); //read character from UART

        //If the buffer is full, shift left
        if (currentLength >= BUFFER_SIZE) {
            memmove(buffer, buffer + 1, BUFFER_SIZE - 1); //it copies the second character to the first and so on.
            currentLength--;
        }

        buffer[currentLength] = receivedChar;
        currentLength++;
        amountChar++; //add amountChar

        
        UART_putString("\033[H\033[J");
                       UART_putString(buffer);
                       if (status_taskFlag==1) {
                                   char text[50];
                                   sprintf(text, "\n\rCharacters: %d", amountChar); //Add spaces for cleanup
                                   UART_putString(text); //Display the new text
                               }


        vTaskDelay(10); //Allow other tasks to run
    }
}

//GPIO Port J Interrupt Handler
void PortJIntHandler(void) {
    uint32_t status = GPIOIntStatus(GPIO_PORTJ_AHB_BASE, true); //Get interrupt status
    GPIOIntClear(GPIO_PORTJ_AHB_BASE, status); //Clear the interrupt

    if (status & BUTTON1) {
        //Give the semaphore to notify the status_task task
        xSemaphoreGiveFromISR(xSemaphoreButton1, NULL);
    }
}

int main(void) {
    xSemaphoreButton1 = xSemaphoreCreateBinary();
    //SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ|SYSCTL_OSC_MAIN|SYSCTL_USE_PLL|SYSCTL_CFG_VCO_480), 120000000);


    ConfigureUART();

    SYSCTL_RCGCGPIO_R |= (1 << 8);   //Enable clock for Port J
    SysCtlDelay(1600 / 3);

    GPIO_PORTJ_AHB_DIR_R &= ~(BUTTON1); //Set PJ0 as input
    GPIO_PORTJ_AHB_DEN_R |= (BUTTON1); //Enable digital function for button
    GPIO_PORTJ_AHB_PUR_R |= (BUTTON1); //Enable pull-up resistors

    //Set up interrupts for buttons
    GPIOIntRegister(GPIO_PORTJ_AHB_BASE, PortJIntHandler);
    GPIOIntTypeSet(GPIO_PORTJ_AHB_BASE, BUTTON1, GPIO_FALLING_EDGE);
    GPIOIntEnable(GPIO_PORTJ_AHB_BASE, BUTTON1);

    //Create tasks
    xTaskCreate(vuartTask, "UART Task", configMINIMAL_STACK_SIZE, NULL, 1, NULL);
    xTaskCreate(vstatus_task, "Status", configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    vTaskStartScheduler();

    while (1); //Should never reach here
}
