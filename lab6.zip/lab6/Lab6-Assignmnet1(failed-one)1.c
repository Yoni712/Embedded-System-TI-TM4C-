#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "UART/configureUART.h"
#include "driverlib/sysctl.h"
#include <stdlib.h>
#include "FreeRTOSConfig.h"


#define BUFFER_SIZE 15  // Define the size of the shared buffer

// Shared variables
char buffer[BUFFER_SIZE];  // Buffer for storing produced bytes
uint32_t Write = 0, Read=0, byteCount = 0, byte;
bool wakeupConsumer=false, wakeupProduce=true;

void ConfigureUART(void){
    UART_reset(); //Call reset
    UART_init(); //Initialize UART
}


//Producer task
uint32_t produceByte(){
    volatile uint32_t i;
    i =  rand()%100;

    return i;
}
void putByteIntoBuffer(){

    buffer[byteCount] = produceByte();
}



void removeByteFromBuffer(){
    buffer[byteCount] = NULL;
}



void vProducerTask(void *pvParameters) {
char text[100];


    while(1){
        if(wakeupProduce){

        if(byteCount == BUFFER_SIZE){
            wakeupProduce=false;
        }

            putByteIntoBuffer();

            sprintf(text, "Produced: %d\n", buffer[byteCount]);
            UART_putString(text);
            byteCount++;



        if (byteCount >1){
            wakeupConsumer = true;
        }
        }
       //vTaskDelay(10);




}
}

// Consumer task
void vConsumerTask(void *pvParameters) {

    char text[100];

    while(1){

        if(wakeupConsumer){
            if(byteCount ==0){
                wakeupConsumer=false;
            }
            removeByteFromBuffer();
            sprintf(text, "Consume: %d\n", buffer[byteCount]);;
            UART_putString(text);
            byteCount--;



        if (byteCount ==BUFFER_SIZE-1){
            wakeupProduce = true;
        }
        }
       //vTaskDelay(10);

   }

}

int main(void) {


    ConfigureUART();

    //Mute = xSemaphoreCreateMutex();



    xTaskCreate(vProducerTask, "produce", configMINIMAL_STACK_SIZE + 200, NULL, 1, NULL);

    xTaskCreate(vConsumerTask, "consume", configMINIMAL_STACK_SIZE + 200, NULL, 1, NULL);

    vTaskStartScheduler();
}
